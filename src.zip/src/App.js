import Home from './Components/Home';
import Pedido from './Components/Pedido';
import Sobre from './Components/Sobre';
import Pizzas from './Components/Pizzas';
import {BrowserRouter, Link, Route, Routes} from 'react-router-dom';
import './App.css';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navbar bg="dark" variant="dark">
        <Container>
          <Nav className="me-auto">
            <Nav.Link id='cores' as={Link} to="/">Home</Nav.Link>
            <Nav.Link id='cores' as={Link} to="/Sobre">Sobre</Nav.Link>
            <Nav.Link id='cores' as={Link} to="/Pedido">Pedido</Nav.Link>
            <Nav.Link id='cores' as={Link} to="/Pizzas">Cardápio</Nav.Link>
          </Nav>
        </Container>
      </Navbar>

      <div className='c'>
        <Routes>
          <Route path="/" element={<Home/>}></Route>
          <Route path="/Sobre" element={<Sobre/>}></Route>
          <Route path="/Pedido" element={<Pedido/>}></Route>
          <Route path="/Pizzas" element={<Pizzas/>}></Route>
        </Routes>
      </div>
      </BrowserRouter>
    </div>
  );
}

export default App;