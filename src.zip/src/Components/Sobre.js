function Sobre(){
    return(
        <div>
            <h5>Essa é a página de mais informações</h5>
        </div>
    )
}

export default Sobre;