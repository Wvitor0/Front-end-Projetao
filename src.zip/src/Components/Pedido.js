import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import './CadastroStyle.css';
import {Link} from 'react-router-dom';
import Nav from 'react-bootstrap/Nav';
import Container from 'react-bootstrap/Container';

function Cadastro(){
    return(
        <div className="cadastro">
            <div className='forms'>
                <Form>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Noma da Pizza</Form.Label>
                    <Form.Control type="email" placeholder="Digite aqui" />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Descrição</Form.Label>
                    <Form.Control type="text" placeholder="Digite aqui" />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicCheckbox">
                    <Form.Check type="checkbox" label="Check me out" />
                </Form.Group>
                <div className='buttons'>
                    <Button id='colorButton' type="submit">
                        Salvar
                    </Button>
                    <Container>
                        <Nav>
                            <Nav.Link id='colorButton2' as={Link} to="/Pizzas">Ver Cardapio</Nav.Link>
                        </Nav>
                    </Container>
                </div>
                </Form>
            </div>
        </div>
    )
}

export default Cadastro;